package simula_food;

public class Cliente {
	String nome;
	int id;
	
	public Cliente(String nome) {
		this.nome = nome;
		
	}
}
