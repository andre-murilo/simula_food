package simula_food;

public class CallbackResult {
	Pedido pedido;
	
	public CallbackResult(Pedido p)
	{
		this.pedido = p;
	}
}
