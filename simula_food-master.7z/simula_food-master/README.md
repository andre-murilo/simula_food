# simula_food

Simulador de restaurante, java Multithreading & PUC Minas
