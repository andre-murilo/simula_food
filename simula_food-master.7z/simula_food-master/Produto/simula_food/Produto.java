package simula_food;

public abstract class Produto {

	public abstract float getPreco();
	public abstract int getTempoPreparo();
	public abstract TipoProduto GetTipo();
	
}
