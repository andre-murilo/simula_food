package simula_food;

public enum TipoProduto {
	FastFood, Bebida, Sobremesa;
}
